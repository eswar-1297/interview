"""SQLAlchemy ORM models."""
from sqlalchemy import Column, Integer, String, Float, Date
from database import Base


class Expense(Base):
    __tablename__ = "expenses"

    id          = Column(Integer, primary_key=True, index=True)
    category    = Column(String, nullable=False)
    amount      = Column(Float, nullable=False)
    description = Column(String, nullable=False)
    date        = Column(Date, nullable=False)
